package com.velsis.monitoring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonitoringApplicationTests {

	@Test
	void contextLoads() {
	}

}
