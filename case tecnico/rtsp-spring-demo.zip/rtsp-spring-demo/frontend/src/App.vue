<script setup>
import {ref, onBeforeUnmount} from 'vue';
import Hls from 'hls.js';
const api = 'http://localhost:8080';
const mode = ref('hls');
const video = ref(null);
const message = ref('Escolha HLS ou WebRTC');
const iframe = ref('');
let hls = null;
const cleanup = () => { if (hls) {hls.destroy(); hls = null;} if (video.value) {video.value.pause();video.value.removeAttribute('src');video.value.load();} iframe.value = ''; };
const startHls = async () => {
  cleanup(); mode.value='hls';
  try {
    const r = await fetch(api + '/api/cameras/1/hls/start',{method:'POST'});
    if (!r.ok) throw new Error(await r.text());
    const {playlist} = await r.json();
    await new Promise(resolve => setTimeout(resolve, 3000));
    const url = api + playlist;
    if (Hls.isSupported()) {hls = new Hls(); hls.loadSource(url);hls.attachMedia(video.value);}
    else if (video.value?.canPlayType('application/vnd.apple.mpegurl')) video.value.src = url;
    else throw new Error('Este navegador não suporta HLS');
    message.value = 'HLS via Spring Boot — ative o áudio pelo controle do player';
  } catch(e){message.value = String(e);}
};
const startWebrtc = async () => {
 cleanup(); mode.value='webrtc';
 try {
   const r = await fetch(api + '/api/cameras/1/webrtc/provision',{method:'POST'});
   if(!r.ok) throw new Error(await r.text());
   const data = await r.json(); iframe.value = data.playerUrl;
   message.value = 'WebRTC via gateway provisionado pelo Spring Boot. Use os controles do player.';
 } catch(e){ message.value=String(e); }
};
const stop = async () => {cleanup(); await fetch(api+'/api/cameras/1/hls/stop',{method:'POST'});message.value='Parado';};
onBeforeUnmount(cleanup);
</script>
<template>
  <main>
    <h1>Camera virtual — RTSP → Spring</h1>
    <p>Compare áudio e vídeo por HLS e WebRTC.</p>
    <div class="buttons"><button @click="startHls">Iniciar HLS</button><button @click="startWebrtc">Iniciar WebRTC</button><button @click="stop">Parar</button></div>
    <p>{{ message }}</p>
    <video v-show="mode==='hls'" ref="video" controls autoplay muted playsinline></video>
    <iframe v-if="mode==='webrtc' && iframe" :src="iframe" allow="autoplay; fullscreen"></iframe>
  </main>
</template>
<style>
body{font:16px system-ui;background:#101929;color:#f5f7fa;margin:0}main{max-width:950px;margin:35px auto;padding:24px}
.buttons{display:flex;gap:12px;flex-wrap:wrap}button{cursor:pointer;padding:12px 18px;border:0;border-radius:7px;background:#287de8;color:white}
video,iframe{width:100%;aspect-ratio:16/9;background:#000;border:0;border-radius:10px;margin-top:12px}
</style>
